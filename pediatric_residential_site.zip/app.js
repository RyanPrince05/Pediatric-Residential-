(function(){
  const cfg = window.SITE_CONFIG;
  // Basic helpers
  const $ = (sel, el=document) => el.querySelector(sel);
  const $$ = (sel, el=document) => Array.from(el.querySelectorAll(sel));

  // Hydrate header/footer
  function setBranding(){
    $('#brandName').textContent = cfg.facilityName;
    $('#footerName').textContent = cfg.facilityName;
    $('#footerName2').textContent = cfg.facilityName;
    $('#footerAddress').textContent = cfg.address;
    $('#footerPhone').textContent = cfg.phone;
    $('#footerPhone').setAttribute('href', 'tel:' + cfg.phone.replace(/[^\d+]/g,''));
    $('#footerEmail').textContent = cfg.email;
    $('#footerEmail').setAttribute('href','mailto:'+cfg.email);
    $('#year').textContent = new Date().getFullYear();
  }

  // Responsive nav
  function setupNav(){
    const btn = $('.nav-toggle');
    const list = $('#navLinks');
    btn.addEventListener('click', () => {
      const exp = btn.getAttribute('aria-expanded') === 'true';
      btn.setAttribute('aria-expanded', String(!exp));
      list.classList.toggle('show');
    });
    $$('#navLinks a').forEach(a => a.addEventListener('click', ()=>list.classList.remove('show')));
  }

  // Views
  const routes = {
    '/': renderHome,
    '/programs': renderPrograms,
    '/admissions': renderAdmissions,
    '/families': renderFamilies,
    '/referrals': renderReferrals,
    '/careers': renderCareers,
    '/contact': renderContact
  };

  function renderHome(){
    const totalBeds = cfg.units.reduce((s,u)=>s+u.beds,0);
    const occupied = Object.values(cfg.occupancy).reduce((s,n)=>s+n,0);
    const open = totalBeds - occupied;

    return `
    <section class="hero">
      <div class="container">
        <div>
          <div class="badges">
            <span class="badge">Trauma‑Informed</span>
            <span class="badge">Family‑Centered</span>
            <span class="badge">School‑Integrated</span>
          </div>
          <h1>Compassionate inpatient residential care for kids and teens.</h1>
          <p>Our three secure units—Elementary, Middle, and High School—each have 10 beds and provide 24/7 nursing, on‑site education, and evidence‑based therapies.</p>
          <div class="cta">
            <a class="btn primary" href="#/admissions">Start an Admission</a>
            <a class="btn" href="#/programs">Explore Programs</a>
            <a class="btn warn" href="tel:${cfg.phone.replace(/[^\d+]/g,'')}">24/7 Admissions Line</a>
          </div>
        </div>
        <div>
          <div class="kpis">
            <div class="kpi"><div class="num">${totalBeds}</div><div>Total Beds</div></div>
            <div class="kpi"><div class="num">${occupied}</div><div>Occupied</div></div>
            <div class="kpi"><div class="num">${open}</div><div>Open</div></div>
          </div>
          <div class="card" style="margin-top:1rem">
            <strong>Current Capacity by Unit</strong>
            <ul>
              ${cfg.units.map(u=>`<li>${u.name}: ${cfg.occupancy[u.key]}/${u.beds} occupied</li>`).join('')}
            </ul>
            <p class="small">Update these numbers in <code>config.js</code> → <code>occupancy</code>.</p>
          </div>
        </div>
      </div>
    </section>

    <section class="container">
      <div class="cards">
        <div class="card">
          <h3>Integrated Education</h3>
          <p>Students continue school with certified teachers, coordinating IEP/504 services with home districts.</p>
        </div>
        <div class="card">
          <h3>Evidence‑Based Care</h3>
          <p>CBT, DBT skills training, family therapy, and medication management tailored to developmental stage.</p>
        </div>
        <div class="card">
          <h3>Family Partnership</h3>
          <p>Weekly family sessions, caregiver training, and structured step‑down planning for smooth transitions.</p>
        </div>
      </div>
      <div class="notice">
        <strong>Insurance & Payment:</strong> We work with Medicaid and most commercial plans. Financial counseling available.
      </div>
    </section>

    <section class="container">
      <h2>Frequently Asked Questions</h2>
      <dl class="faq">
        <dt>How long is the typical stay?</dt>
        <dd>Average 10–21 days, individualized by clinical need and discharge plan.</dd>
        <dt>Can families visit?</dt>
        <dd>Yes. Visiting hours ${cfg.visiting}. Additional times can be arranged with the care team.</dd>
        <dt>Do you accept emergency admissions?</dt>
        <dd>Yes, 24/7 pending medical clearance and clinical criteria.</dd>
      </dl>
    </section>
    `;
  }

  function renderPrograms(){
    return `
    <section class="container" style="padding:2rem 1rem">
      <h1>Programs & Units</h1>
      <p>Three developmentally distinct residential units ensure the right milieu, schooling, and therapies for each patient.</p>
      <div class="grid-3" style="margin-top:1rem">
        ${cfg.units.map(u=>`
          <article class="card">
            <h3>${u.name}</h3>
            <p><strong>${u.grades}</strong> • ${u.ages} • ${u.levelOfCare}</p>
            <ul>
              <li>Capacity: ${u.beds} beds</li>
              <li>Daily schedule with academics, therapy, recreation</li>
              <li>On‑site nursing & psychiatry</li>
              <li>Family therapy & discharge planning</li>
            </ul>
          </article>
        `).join('')}
      </div>
    </section>
    `;
  }

  function renderAdmissions(){
    return `
    <section class="container" style="padding:2rem 1rem">
      <h1>Admissions</h1>
      <p>We accept referrals 24/7 from EDs, outpatient providers, schools, and caregivers. Criteria include safety stabilization needs, diagnostic clarification, and failure of lower levels of care.</p>
      <div class="grid-2" style="margin-top:1rem">
        <div class="card">
          <h3>Start a Referral</h3>
          <form id="referralForm" class="stack" novalidate>
            <label>Patient Name<input required name="patientName" placeholder="First Last"></label>
            <label>Patient DOB<input required name="dob" type="date"></label>
            <label>Referral Source<select required name="source">
              <option value="">Select</option>
              <option>Parent/Caregiver</option>
              <option>School</option>
              <option>ED/Hospital</option>
              <option>Outpatient Clinician</option>
              <option>Other</option>
            </select></label>
            <label>Primary Concern<textarea required name="concern" rows="4" placeholder="Brief summary"></textarea></label>
            <label>Contact Email<input required name="email" type="email" placeholder="you@example.com"></label>
            <button class="btn primary" type="submit">Submit Referral</button>
            <p class="small">Submitting this form demonstrates functionality only. Connect to your preferred form backend to receive submissions.</p>
          </form>
        </div>
        <div class="card">
          <h3>What to Expect</h3>
          <ol>
            <li>Rapid review by our admissions clinician</li>
            <li>Benefits & authorization check</li>
            <li>Intake scheduling and safe transport guidance</li>
          </ol>
          <p><strong>Questions?</strong> Call our admissions line at <a href="tel:${cfg.phone.replace(/[^\d+]/g,'')}">${cfg.phone}</a>.</p>
        </div>
      </div>
    </section>
    `;
  }

  function renderFamilies(){
    return `
    <section class="container" style="padding:2rem 1rem">
      <h1>Families & Visitors</h1>
      <div class="grid-2" style="margin-top:1rem">
        <div class="card">
          <h3>Visiting Hours</h3>
          <p>${cfg.visiting}. Please bring a photo ID. Items allowed on the unit are limited; ask staff before bringing personal belongings.</p>
          <h3>Communication</h3>
          <p>Daily nursing updates and weekly family therapy. Secure video visits are available when travel is difficult.</p>
        </div>
        <div class="card">
          <h3>Education & Schoolwork</h3>
          <p>Students remain enrolled in their home school. Our teachers coordinate with districts to continue coursework and support IEP/504 plans.</p>
          <h3>Discharge Planning</h3>
          <p>We partner with caregivers to plan outpatient therapy, psychiatry, and school supports before discharge.</p>
        </div>
      </div>
    </section>
    `;
  }

  function renderReferrals(){
    return `
    <section class="container" style="padding:2rem 1rem">
      <h1>Clinician & School Referrals</h1>
      <div class="grid-2" style="margin-top:1rem">
        <div class="card">
          <h3>Criteria & Exclusions</h3>
          <ul>
            <li>Acute safety risks requiring structured monitoring</li>
            <li>Failure of outpatient or partial hospitalization</li>
            <li>Co‑occurring medical needs must be stable</li>
            <li>We cannot accept patients requiring forensic holds</li>
          </ul>
        </div>
        <div class="card">
          <h3>Documents We Request</h3>
          <ul>
            <li>Recent H&P and medication list</li>
            <li>Psych evals, IEP/504, behavior plans</li>
            <li>Insurance info and guardian contacts</li>
          </ul>
        </div>
      </div>
    </section>
    `;
  }

  function renderCareers(){
    return `
    <section class="container" style="padding:2rem 1rem">
      <h1>Careers</h1>
      <p>Join a mission‑driven team delivering exceptional pediatric behavioral healthcare.</p>
      <div class="cards">
        <div class="card"><h3>RN (All Shifts)</h3><p>Inpatient pediatric behavioral health experience preferred.</p><a class="btn" href="#/contact">Apply</a></div>
        <div class="card"><h3>Behavioral Health Tech</h3><p>Support therapeutic milieu and patient safety.</p><a class="btn" href="#/contact">Apply</a></div>
        <div class="card"><h3>Teacher (K‑12)</h3><p>Coordinate with home districts; IEP experience a plus.</p><a class="btn" href="#/contact">Apply</a></div>
      </div>
    </section>
    `;
  }

  function renderContact(){
    return `
    <section class="container" style="padding:2rem 1rem">
      <h1>Contact Us</h1>
      <div class="grid-2" style="margin-top:1rem">
        <div class="card">
          <h3>General Inquiries</h3>
          <form id="contactForm" class="stack" novalidate>
            <label>Your Name<input required name="name" placeholder="First Last"></label>
            <label>Email<input required name="email" type="email" placeholder="you@example.com"></label>
            <label>Message<textarea required name="message" rows="5" placeholder="How can we help?"></textarea></label>
            <button class="btn primary" type="submit">Send Message</button>
            <p class="small">This demo form shows client‑side validation and a success state.</p>
          </form>
        </div>
        <div class="card">
          <h3>Call or Visit</h3>
          <p><strong>${cfg.facilityName}</strong><br>${cfg.address}<br>
          Phone: <a href="tel:${cfg.phone.replace(/[^\d+]/g,'')}">${cfg.phone}</a><br>
          Email: <a href="mailto:${cfg.email}">${cfg.email}</a></p>
          <div class="notice">For emergencies, call 911 or visit the nearest emergency department.</div>
        </div>
      </div>
    </section>
    `;
  }

  // Router
  function render(){
    const hash = location.hash.replace('#','') || '/';
    const view = $('#view');
    const fn = routes[hash] || routes['/'];
    view.innerHTML = fn();
    // Focus main for a11y after navigation
    $('#main').focus();
    setupForms();
  }

  // Forms: simple validation + "fake submit" success message
  function setupForms(){
    $$('form').forEach(form => {
      form.addEventListener('submit', e => {
        e.preventDefault();
        const valid = form.checkValidity();
        form.classList.add('was-validated');
        if(!valid){ 
          alert('Please complete required fields.');
          return;
        }
        const data = Object.fromEntries(new FormData(form).entries());
        if (cfg.useMailto && form.id === 'contactForm'){
          window.location.href = `mailto:${cfg.email}?subject=Website Inquiry&body=${encodeURIComponent(JSON.stringify(data,null,2))}`;
          return;
        }
        // Show success message inline
        form.innerHTML = '<div class="notice"><strong>Thank you!</strong> Your information was submitted successfully (demo).</div>';
      });
    });
  }

  // Init
  setBranding();
  setupNav();
  window.addEventListener('hashchange', render);
  render();
})();