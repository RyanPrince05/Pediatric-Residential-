// You can customize your facility info here.
// Update these values and the site will use them automatically.
window.SITE_CONFIG = {
  facilityName: "Bluegrass Pediatric Residential Center",
  address: "1234 Example Way, Louisville, KY 40202",
  phone: "(502) 555-1234",
  email: "info@example.org",
  units: [
    { key: "elementary", name: "Elementary Unit", grades: "Grades 1–5", ages: "Approx. ages 6–10", beds: 10, levelOfCare: "Residential (inpatient)" },
    { key: "middle", name: "Middle School Unit", grades: "Grades 6–8", ages: "Approx. ages 11–13", beds: 10, levelOfCare: "Residential (inpatient)" },
    { key: "high", name: "High School Unit", grades: "Grades 9–12", ages: "Approx. ages 14–17", beds: 10, levelOfCare: "Residential (inpatient)" }
  ],
  // Initial occupancy (edit as needed)
  occupancy: {
    elementary: 0,
    middle: 0,
    high: 0
  },
  visiting: "Sat–Sun 1–4pm",
  // Set this to true if you want forms to try a mailto: action (opens user's email client)
  useMailto: false
};
