# Bluegrass Pediatric Residential Center — Static Website

This is a **ready-to-deploy static site** for a pediatric inpatient residential facility with three units (Elementary, Middle, High School), **10 beds each**.

## Quick Start

1. Open `config.js` and update:
   - `facilityName`, `address`, `phone`, `email`
   - `occupancy` for each unit
2. Open `index.html` in your browser — you're live.

## Deploy (GitHub Pages)

1. Create a new GitHub repo and upload these files.
2. In your repo, go to **Settings → Pages**, set **Source** to **Deploy from a branch**, choose the **main** branch and `/ (root)`.
3. Your site will go live at `https://YOUR-USER.github.io/YOUR-REPO/`.

## Deploy (Netlify)

- Drag-and-drop the folder onto https://app.netlify.com/drop or connect your repo. No build needed.

## Edit Bed Counts

- In `config.js` → `occupancy`, update numbers for `elementary`, `middle`, `high`.
- The homepage dashboard updates automatically.

## Forms

- Forms are **front-end only** by default. To receive real submissions:
  - Use Netlify Forms, Formspree, or connect your own backend.
  - Set `useMailto: true` in `config.js` to open the user's email client for the Contact form.
  - The current demo shows a success message so you can test flows without a server.

## Accessibility

- Semantic HTML, skip link, focus management after navigation.
- Color contrast verified for primary flows.

## Tech

- SPA using vanilla JS (hash routing), Inter font, custom CSS. No frameworks.
- Easy to host as static files anywhere.

© 2025 Bluegrass Pediatric Residential Center
